// src/pages/Login.jsx
// Jednoduchá in-app prihlasovacia obrazovka (Supabase Auth).
import React, { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setError(null);
    setLoading(true);
    const res = await login(email.trim(), password);
    setLoading(false);
    if (!res.ok) setError(res.error || 'Prihlásenie zlyhalo. Skontrolujte e-mail a heslo.');
  };

  const onKeyDown = (e) => { if (e.key === 'Enter') handleSubmit(); };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gov-light px-4">
      <div className="w-full max-w-sm bg-white rounded-2xl border border-slate-200 shadow-sm p-8">
        <div className="flex flex-col items-center mb-6">
          <div className="w-12 h-12 rounded-xl bg-gov-blue/10 flex items-center justify-center text-2xl">🏛️</div>
          <h1 className="mt-3 text-lg font-semibold text-slate-800">MatrikaCloud</h1>
          <p className="text-sm text-slate-500">Prihlásenie do systému</p>
        </div>

        <label className="block text-sm font-medium text-slate-700 mb-1">E-mail</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          onKeyDown={onKeyDown}
          autoComplete="username"
          className="w-full mb-4 px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-gov-blue/40"
          placeholder="meno@obec.sk"
        />

        <label className="block text-sm font-medium text-slate-700 mb-1">Heslo</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={onKeyDown}
          autoComplete="current-password"
          className="w-full mb-4 px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-gov-blue/40"
          placeholder="••••••••"
        />

        {error && (
          <div className="mb-4 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
            {error}
          </div>
        )}

        <button
          onClick={handleSubmit}
          disabled={loading || !email || !password}
          className="w-full py-2.5 rounded-lg bg-gov-blue text-white font-medium hover:opacity-90 disabled:opacity-50 transition"
        >
          {loading ? 'Prihlasujem…' : 'Prihlásiť sa'}
        </button>

        <p className="mt-4 text-xs text-slate-400 text-center">
          Účet vytvára správca v Supabase (Authentication → Add user).
        </p>
      </div>
    </div>
  );
}
