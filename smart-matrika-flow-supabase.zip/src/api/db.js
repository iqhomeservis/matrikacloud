// src/api/db.js
// =====================================================================
// Drop-in náhrada Base44 SDK -> Supabase (master DB).
// Schémy: matrika (doména) + licensing (licencie/heartbeat) + shared (org/profil).
// Zachováva tvar:  base44.entities.X.{list,filter,get,create,update,delete,bulkCreate}
//                  base44.auth.{me,logout,redirectToLogin,signInWithPassword}
// Stránky aj src/lib sa nemenia — base44Client.js re-exportuje base44 odtiaľto.
// =====================================================================
import { supabase } from './supabaseClient';

// Mapovanie Base44 entít na tabuľky master DB.
// Licencia / HeartbeatLog / LicencneUdalostiLog idú do zdieľanej schémy `licensing`
// a automaticky sa im doplní application:'matrika'.
const ENTITY_MAP = {
  Nastavenia:          { schema: 'matrika',   table: 'settings' },
  Licencia:            { schema: 'licensing', table: 'licenses',       application: 'matrika' },
  LicencneUdalostiLog: { schema: 'licensing', table: 'license_events', application: 'matrika' },
  HeartbeatLog:        { schema: 'licensing', table: 'heartbeats',     application: 'matrika' },
  OverovaciaKniha:     { schema: 'matrika',   table: 'verification_records' },
  PPDDoklad:           { schema: 'matrika',   table: 'receipts' },
  PPDNastavenia:       { schema: 'matrika',   table: 'receipt_settings' },
  ScannerPlugin:       { schema: 'matrika',   table: 'scanner_plugins' },
  Zaloha:              { schema: 'matrika',   table: 'backups' },
  AuditLog:            { schema: 'matrika',   table: 'audit_log' },
};

// Base44 systémové polia, ktoré sa pri zápise odstránia (DB ich rieši sama)
const SYSTEM_FIELDS = ['id', 'created_date', 'updated_date', 'created_by', 'created_by_id', 'is_sample', 'app_id'];
// mapovanie sort polí Base44 -> naše stĺpce
const SORT_MAP = { created_date: 'created_at', updated_date: 'updated_at' };

function parseSort(sort) {
  if (!sort) return null;
  const desc = sort.startsWith('-');
  const raw = desc ? sort.slice(1) : sort;
  return { column: SORT_MAP[raw] || raw, ascending: !desc };
}
function stripSystem(data) {
  const out = {};
  for (const [k, v] of Object.entries(data || {})) if (!SYSTEM_FIELDS.includes(k)) out[k] = v;
  return out;
}
// kompatibilita: doplní created_date/updated_date z created_at/updated_at
function normalizeRow(row) {
  if (!row) return row;
  if (row.created_at && row.created_date === undefined) row.created_date = row.created_at;
  if (row.updated_at && row.updated_date === undefined) row.updated_date = row.updated_at;
  return row;
}
const normalize = (rows) => (Array.isArray(rows) ? rows.map(normalizeRow) : normalizeRow(rows));

// ---- aktuálna organizácia (obec) prihláseného používateľa ----
let _orgId = null;
export async function getCurrentOrgId() {
  if (_orgId) return _orgId;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data, error } = await supabase
    .schema('shared').from('memberships')
    .select('organization_id').eq('user_id', user.id).limit(1).maybeSingle();
  if (error) throw error;
  _orgId = data?.organization_id || null;
  return _orgId;
}
export function clearOrgCache() { _orgId = null; }

function makeEntity(name) {
  const { schema, table, application } = ENTITY_MAP[name];
  const tbl = () => supabase.schema(schema).from(table);
  return {
    async list(sort, limit) {
      let q = tbl().select('*');
      const s = parseSort(sort);
      if (s) q = q.order(s.column, { ascending: s.ascending });
      if (limit) q = q.limit(limit);
      const { data, error } = await q;
      if (error) throw error;
      return normalize(data);
    },
    async filter(query, sort, limit) {
      let q = tbl().select('*');
      for (const [k, v] of Object.entries(query || {})) q = q.eq(k, v);
      const s = parseSort(sort);
      if (s) q = q.order(s.column, { ascending: s.ascending });
      if (limit) q = q.limit(limit);
      const { data, error } = await q;
      if (error) throw error;
      return normalize(data);
    },
    async get(id) {
      const { data, error } = await tbl().select('*').eq('id', id).single();
      if (error) throw error;
      return normalizeRow(data);
    },
    async create(payload) {
      const orgId = await getCurrentOrgId();
      if (!orgId) throw new Error('Chýba organizácia (obec). Spustite bootstrapObec() / prihlásenie.');
      const row = { ...stripSystem(payload), organization_id: payload.organization_id || orgId };
      if (application && !row.application) row.application = application;
      const { data, error } = await tbl().insert(row).select().single();
      if (error) throw error;
      return normalizeRow(data);
    },
    async bulkCreate(arr) {
      const orgId = await getCurrentOrgId();
      const rows = (arr || []).map((p) => {
        const row = { ...stripSystem(p), organization_id: p.organization_id || orgId };
        if (application && !row.application) row.application = application;
        return row;
      });
      const { data, error } = await tbl().insert(rows).select();
      if (error) throw error;
      return normalize(data);
    },
    async update(id, payload) {
      const { data, error } = await tbl().update(stripSystem(payload)).eq('id', id).select().single();
      if (error) throw error;
      return normalizeRow(data);
    },
    async delete(id) {
      const { error } = await tbl().delete().eq('id', id);
      if (error) throw error;
      return { id };
    },
  };
}

const entities = {};
for (const name of Object.keys(ENTITY_MAP)) entities[name] = makeEntity(name);

// ---- auth shim (Base44 -> Supabase Auth) ----
const auth = {
  async me() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Neprihlásený');
    const { data: profile } = await supabase
      .schema('shared').from('profiles').select('*').eq('user_id', user.id).maybeSingle();
    const { data: membership } = await supabase
      .schema('shared').from('memberships').select('organization_id, role').eq('user_id', user.id).limit(1).maybeSingle();
    const isAdmin = !!profile?.is_platform_admin || membership?.role === 'admin';
    return {
      id: user.id,
      email: user.email,
      full_name: profile?.full_name || user.email,
      role: isAdmin ? 'admin' : 'user',          // zhoda s Base44 User.role (admin|user)
      organization_id: membership?.organization_id || null,
    };
  },
  async logout() { clearOrgCache(); await supabase.auth.signOut(); },
  redirectToLogin() { window.location.href = '/login'; },
  async signInWithPassword(email, password) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    clearOrgCache();
    return data;
  },
};

// ---- bootstrap obce (jednorazovo pri prvom prihlásení admina) ----
export async function bootstrapObec({ obecNazov, obecIco, kraj, okres, adresaUradu }) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Neprihlásený');
  const existing = await getCurrentOrgId();
  if (existing) return existing;

  let addressId = null;
  if (adresaUradu || kraj || okres) {
    const { data: addr } = await supabase.schema('shared').from('addresses')
      .insert({ street: adresaUradu, region: kraj, district: okres, country: 'SK' })
      .select().single();
    addressId = addr?.id || null;
  }
  const { data: org, error: orgErr } = await supabase.schema('shared').from('organizations')
    .insert({ name: obecNazov, type: 'public_authority', ico: obecIco, address_id: addressId })
    .select().single();
  if (orgErr) throw orgErr;

  await supabase.schema('shared').from('profiles')
    .upsert({ user_id: user.id, full_name: user.email, email: user.email, primary_org_id: org.id }, { onConflict: 'user_id' });
  await supabase.schema('shared').from('memberships')
    .insert({ user_id: user.id, organization_id: org.id, role: 'admin' });

  clearOrgCache();
  return org.id;
}

export const base44 = { entities, auth };
export default base44;
