// src/api/base44Client.js
// PRESMEROVANÉ z Base44 na Supabase (master DB).
// Ostatné súbory ďalej importujú { base44 } odtiaľto a dostanú Supabase adapter.
// Vďaka tomu sa stránky a src/lib nemusia meniť.
export { base44, getCurrentOrgId, clearOrgCache, bootstrapObec } from './db';
export { base44 as default } from './db';
